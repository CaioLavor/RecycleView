package br.unimes.listas.model

data class User(
    val name:String,
    val age: Int
)
